/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio3java;

/**
 *
 * @author Usuario
 */
public class Ejercicio3Java {

    public static void main(String[] args) {
        
        Coche coche1 = new Coche("Toyota", "Corolla");
        Coche coche2 = new Coche("Ford", "Mustang");

        
        coche1.acelerar();
        coche1.acelerar();
        coche1.frenar();
        coche1.mostrarVelocidad();

        
        coche2.acelerar();
        coche2.frenar();
        coche2.frenar(); 
        coche2.mostrarVelocidad();
    }
}
