/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio3java;

/**
 *
 * @author Usuario
 */
public class Coche {
    
    private String marca;
    private String modelo;
    private int velocidad;

    
    public Coche(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
        this.velocidad = 0; 
    }

    
    public void acelerar() {
        velocidad += 10;
        System.out.println(marca + " " + modelo + " aceleró. Velocidad: " + velocidad + " km/h");
    }

    
    public void frenar() {
        if (velocidad >= 5) {
            velocidad -= 5;
        } else {
            velocidad = 0;
        }
        System.out.println(marca + " " + modelo + " frenó. Velocidad: " + velocidad + " km/h");
    }

    
    public void mostrarVelocidad() {
        System.out.println("Velocidad actual del " + marca + " " + modelo + ": " + velocidad + " km/h");
    }
}