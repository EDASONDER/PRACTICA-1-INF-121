/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio1java;

/**
 *
 * @author Usuario
 */
public class Ejercicio1Java {

    public static void main(String[] args) {
        
        Persona persona1 = new Persona("Juan", 25, "Lima");
        Persona persona2 = new Persona("Ana", 16, "Arequipa");
        Persona persona3 = new Persona("Carlos", 30, "Cusco");

        
        persona1.saludar();
        System.out.println("¿Es mayor de edad? " + persona1.esMayorDeEdad());

        persona2.saludar();
        System.out.println("¿Es mayor de edad? " + persona2.esMayorDeEdad());

        persona3.saludar();
        System.out.println("¿Es mayor de edad? " + persona3.esMayorDeEdad());
    }
}
