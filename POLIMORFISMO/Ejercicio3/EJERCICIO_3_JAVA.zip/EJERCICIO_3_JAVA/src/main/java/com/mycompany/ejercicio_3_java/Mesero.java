/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_3_java;

/**
 *
 * @author Usuario
 */
public class Mesero extends Empleado {
    private int horasExtra;
    private double sueldoHora;
    private double propina;
    
    public Mesero(String nombre, double sueldoMes, int horasExtra, double sueldoHora, double propina) {
        super(nombre, sueldoMes);
        this.horasExtra = horasExtra;
        this.sueldoHora = sueldoHora;
        this.propina = propina;
    }
    
    @Override
    public double sueldoTotal() {
        return sueldoMes + (horasExtra * sueldoHora) + propina;
    }
}