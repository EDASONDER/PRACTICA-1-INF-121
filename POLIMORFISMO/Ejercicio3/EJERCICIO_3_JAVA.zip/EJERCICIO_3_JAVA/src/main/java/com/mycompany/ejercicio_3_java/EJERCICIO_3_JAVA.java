/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_3_java;

/**
 *
 * @author Usuario
 */
public class EJERCICIO_3_JAVA {

    public static void main(String[] args) {
        // a) Instanciar empleados
        Cocinero chef = new Cocinero("Carlos", 2000, 10, 15.5);
        Mesero mesero1 = new Mesero("Juan", 1500, 5, 10.0, 200);
        Mesero mesero2 = new Mesero("Ana", 1600, 8, 10.0, 300);
        Administrativo admin1 = new Administrativo("Luisa", 2500.50, "Gerente");
        Administrativo admin2 = new Administrativo("Pedro", 1600, "Asistente");

        // b) Calcular sueldos totales
        System.out.println("--- Sueldos Totales ---");
        System.out.println(chef.nombre + ": $" + chef.sueldoTotal());
        System.out.println(mesero1.nombre + ": $" + mesero1.sueldoTotal());
        System.out.println(mesero2.nombre + ": $" + mesero2.sueldoTotal());
        System.out.println(admin1.nombre + ": $" + admin1.sueldoTotal());
        System.out.println(admin2.nombre + ": $" + admin2.sueldoTotal());

        // c) Mostrar empleados con sueldoMes = 1600
        System.out.println("\n--- Empleados con sueldo base $1600 ---");
        Empleado[] empleados = {chef, mesero1, mesero2, admin1, admin2};
        for (Empleado emp : empleados) {
            if (emp.sueldoMes == 1600) {
                System.out.println(emp.nombre + " - Sueldo base: $" + emp.sueldoMes);
            }
        }
    }
}
