/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_3_java;

/**
 *
 * @author Usuario
 */
public class Cocinero extends Empleado {
    private int horasExtra;
    private double sueldoHora;
    
    public Cocinero(String nombre, double sueldoMes, int horasExtra, double sueldoHora) {
        super(nombre, sueldoMes);
        this.horasExtra = horasExtra;
        this.sueldoHora = sueldoHora;
    }
    
    @Override
    public double sueldoTotal() {
        return sueldoMes + (horasExtra * sueldoHora);
    }
}