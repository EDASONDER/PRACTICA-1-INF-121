/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_3_java;

/**
 *
 * @author Usuario
 */

public class Empleado {
    protected String nombre;
    protected double sueldoMes;
    
    public Empleado(String nombre, double sueldoMes) {
        this.nombre = nombre;
        this.sueldoMes = sueldoMes;
    }
    
    public double sueldoTotal() {
        return sueldoMes;
    }
}