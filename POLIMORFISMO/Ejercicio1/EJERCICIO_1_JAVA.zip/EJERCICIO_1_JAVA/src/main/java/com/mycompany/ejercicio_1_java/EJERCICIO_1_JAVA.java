/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_1_java;

/**
 *
 * @author Usuario
 */
public class EJERCICIO_1_JAVA {

    public static void main(String[] args) {
        // a) Instanciar 2 videojuegos (usando diferentes constructores)
        Videojuego juego1 = new Videojuego("The Legend of Zelda", "Nintendo Switch", 1);
        Videojuego juego2 = new Videojuego("Minecraft", "PC");

        // b) Mostrar datos
        juego1.mostrar();
        juego2.mostrar();

        // c) Agregar jugadores (sobrecarga)
        juego1.agregarJugadores();      // +1 jugador
        juego2.agregarJugadores(4);     // +4 jugadores

        // Mostrar cambios
        System.out.println("\n--- Después de agregar jugadores ---");
        juego1.mostrar();
        juego2.mostrar();
    }
}
